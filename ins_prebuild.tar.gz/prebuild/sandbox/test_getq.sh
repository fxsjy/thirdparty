#!/bin/bash
../output/bin/ins_cli --ins_cmd=getq --flagfile=ins.flag --ins_key=$1

