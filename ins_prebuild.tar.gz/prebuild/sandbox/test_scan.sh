#!/bin/bash
../output/bin/ins_cli --ins_cmd=scan --flagfile=ins.flag --ins_start_key=$1 --ins_end_key=$2

