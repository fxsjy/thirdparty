#!/bin/bash
../output/bin/ins_cli --ins_cmd=register --flagfile=ins.flag --ins_key=$1 --ins_value=$2

