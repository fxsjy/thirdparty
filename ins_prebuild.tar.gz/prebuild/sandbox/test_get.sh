#!/bin/bash
../output/bin/ins_cli --ins_cmd=get --flagfile=ins.flag --ins_key=$1

