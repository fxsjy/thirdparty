#!/bin/bash
../output/bin/ins_cli --ins_cmd=delete --flagfile=ins.flag --ins_key=$1

