#!/bin/bash
../output/bin/ins_cli --ins_cmd=stat --flagfile=ins.flag
